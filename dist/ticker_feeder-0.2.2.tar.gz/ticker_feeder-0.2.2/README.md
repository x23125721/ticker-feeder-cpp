# Ticker Feeder

Simple Python library to feed data.
