def feed(data):
    print('Feeding data:', data)
